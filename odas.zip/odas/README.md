## ODAS MATLAB Library

A collection of functions for reading, manipulating, and processing ODAS data files recorded by RSI instruments.
